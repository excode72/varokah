# deeniedoank

# Cinta7
```
wget https://raw.githubusercontent.com/elangoverdosis/deeniedoank/debian7/cinta7.sh && chmod +x ./cinta7.sh && ./cinta7.sh
```
# OPENVPN
```
wget -O openvpn.sh https://raw.githubusercontent.com/elangoverdosis/deeniedoank/debian7/openvpn.sh && chmod +x openvpn.sh && ./openvpn.sh
```
















# Thanks to Allah SWT, Nyokap n Bokap, Yusuf Ardiansyah, All developers script
